/*
 * Joy_stick_pass.c
 *
 * Created: 12/31/2023 11:27:27 PM
 *  Author: CARNIVAL
 */ 

#include "Joy_stick_seq_game.h"

Joy_stick_state password_Joy[PASSWORD_JOY_LENGTH] = {UP, DOWN, LEFT, RIGHT, DOWN, UP, DOWN};
	
static void LCD_Print(Joy_stick_state state) {
	switch (state) {
		case UP:
			LCD_SendString("UP");
		break;
		case DOWN:
			LCD_SendString("DOWN");
		break;
		case RIGHT:
			LCD_SendString("RIGHT");
		break;
		case LEFT:
			LCD_SendString("LEFT");
		break;
	}
}

password_Joy_State enter_Password_Joy() {
	Joy_stick_state state_Prev = CENTER;
	Joy_stick_state state_Current = CENTER;

	uint8 counter = ZERO;
	
	LCD_command(CLEAR_SCREEN);
	_delay_ms(50);
	LCD_SendString("Solve the ");
	LCD_command(CURSOR_BEGIN_LINE2);
	LCD_SendString("PUZZLE !!!!");
	_delay_ms(150);

	while (counter < PASSWORD_JOY_LENGTH) {
		state_Current = Joy_read();
		
		if (CENTER == state_Current) {
			_delay_ms(5);
			LCD_command(CLEAR_SCREEN);
			_delay_ms(5);
		}
		else if (state_Current != state_Prev) {
			state_Prev = state_Current;
			_delay_ms(5);
			LCD_Print(state_Current);
			_delay_ms(75);
			if (state_Current != password_Joy[counter]) {
				LCD_command(CLEAR_SCREEN);
				_delay_ms(5);
				LCD_SendString("Wrong");
				_delay_ms(50);
				
				return WRONG;
			}
			counter++;
		}
	}
		
	LCD_command(CLEAR_SCREEN);
	_delay_ms(5);
	LCD_SendString("Correct");
	_delay_ms(50);
		
	return CORRECT;
}