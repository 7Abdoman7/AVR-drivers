/*
 * Joy_stick_pass.h
 *
 * Created: 12/31/2023 11:27:16 PM
 *  Author: CARNIVAL
 */ 

#ifndef _JOY_STICK_PASS_H_
#define _JOY_STICK_PASS_H_

#include "../../HAL/JOY_STICK/Joy_stick.h"
#include "../../HAL/LCD/Lcd.h"

#define PASSWORD_JOY_LENGTH		(7)

typedef enum {
	CORRECT,
	WRONG
}password_Joy_State;

password_Joy_State enter_Password_Joy();


#endif