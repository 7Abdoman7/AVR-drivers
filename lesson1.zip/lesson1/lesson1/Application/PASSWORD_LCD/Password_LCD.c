/*
 * Password_LCD.c
 *
 * Created: 12/25/2023 11:32:35 AM
 *  Author: CARNIVAL
 */ 

#include "Password_LCD.h"

static password_State check_Password(uint8 *str) {
	if (strcmp(str, PASSWORD) == 0) {
		return CORRECT;
	}	
	else {
		return WRONG;
	}
}

password_State enter_Password() {
	uint8 password_Temp[PASSWORD_LENGTH];
	uint8 counter = ZERO;
	
	Buzzer_Turn_Off(BUZZER_PIN);

	LCD_command(CLEAR_SCREEN);
	_delay_ms(5);
	LCD_SendString("Enter password: ");
	_delay_ms(5);
	LCD_command(CURSOR_BEGIN_LINE2);
	_delay_ms(5);
	
	for (counter = ZERO; counter < PASSWORD_LENGTH; counter++) {
		password_Temp[counter] = Keypad_Get(keypad);
		_delay_ms(5);
		LCD_SendChar(password_Temp[counter]);
		_delay_ms(5);
	}
	
	password_Temp[counter] = '\0';
	
	if (CORRECT == check_Password(password_Temp)) {
		LCD_command(CLEAR_SCREEN);
		_delay_ms(5);
		LCD_SendString("Correct");
		_delay_ms(5);
		
		return CORRECT;
	}
	else {
		LCD_command(CLEAR_SCREEN);
		_delay_ms(5);
		LCD_SendString("Wrong");
		_delay_ms(5);
		Buzzer_Turn_On(BUZZER_PIN);
		_delay_ms(10);
		Buzzer_Turn_Off(BUZZER_PIN);
		_delay_ms(10);		
				
		return WRONG;
	}
}
