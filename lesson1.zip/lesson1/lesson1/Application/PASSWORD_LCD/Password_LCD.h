/*
 * Password_LCD.h
 *
 * Created: 12/25/2023 11:32:52 AM
 *  Author: CARNIVAL
 */ 
#ifndef _PASSWORD_LCD_H_
#define _PASSWORD_LCD_H_

#include "../../HAL/LCD/Lcd.h"
#include "../../HAL/KEYPAD/Keypad.h"
#include "../../HAL/BUZZER/Buzzer.h"

#define PASSWORD_LENGTH		(4)
#define PASSWORD			"1234"

typedef enum {
	CORRECT,
	WRONG
}password_State;

password_State enter_Password();

#endif /*_PASSWORD_LCD_H_*/