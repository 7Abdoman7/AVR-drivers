/*
 * Servo_Blue.c
 *
 * Created: 2/19/2024 5:54:30 AM
 *  Author: Abdo
 */ 
#include "Servo_Blue.h"

void servo_GetMove(uint8 move) {
	uint16 current_Angle = ZERO;
	uint8 angle_Str[10];
	
	current_Angle = servo_GetAngle();
	itoa(current_Angle, angle_Str, 10);
	
	blue_sendString("The angle = ");
	blue_sendString(angle_Str);
	blue_sendChar('\n');
				
	if ('R' == move || 'r' == move) {
		if (42 > current_Angle) {
			blue_sendString("WE REACHED THE LIMIT OF RIGHT\n");
			LCD_SendString("MAX RIGHT");
		}
		else {
			servo_move(current_Angle - 5);
		}
	}
	
	if ('L' == move || 'l' == move) {
		if (172 < current_Angle) {
			blue_sendString("WE REACHED THE LIMIT OF LEFT\n");
			LCD_SendString("MAX LEFT");
		}
		else {
			servo_move(current_Angle + 5);
		}
	}
}