/*
 * Servo_Blue.h
 *
 * Created: 2/19/2024 5:54:19 AM
 *  Author: Abdo
 */ 

#ifndef _SERVO_BLUE_H_
#define _SERVO_BLUE_H_

#include "../../HAL/BLUETOOTH/Bluetooth.h"
#include "../../HAL/SERVO/Servo.h"
#include "../../HAL/LCD/Lcd.h"

void servo_GetMove(uint8 move);

#endif