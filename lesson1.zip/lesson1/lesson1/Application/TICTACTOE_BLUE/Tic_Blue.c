/*
 * Tic_Blue.c
 *
 * Created: 2/16/2024 2:57:03 PM
 *  Author: Abdo
 */ 

#include "Tic_Blue.h"

void board_init(uint8 board[ROW_SIZE][COL_SIZE]) {
    uint32 row_Counter = ZERO;
    uint32 col_Counter = ZERO;

    for (row_Counter = ZERO; row_Counter < ROW_SIZE; row_Counter++) {
        for (col_Counter = ZERO; col_Counter < COL_SIZE; col_Counter++) {
            board[row_Counter][col_Counter] = 'N';
        }
    }
}

void print_board(uint8 board[ROW_SIZE][COL_SIZE]) {
    uint32 row_Counter = ZERO;
    uint32 col_Counter = ZERO;
    
    blue_sendChar('\n');
    
    for (row_Counter = ZERO; row_Counter < ROW_SIZE; row_Counter++) {
        for (col_Counter = ZERO; col_Counter < COL_SIZE; col_Counter++) {
            if (col_Counter == ZERO)
                blue_sendString("       ");
                
            blue_sendChar(board[row_Counter][col_Counter]);
            
            blue_sendString("   ");
            
            if (col_Counter < 2) blue_sendString("|  ");
        }
        
        blue_sendChar('\n');
        
        if (row_Counter < 2) blue_sendString("     ------+------+------\n");
    }
    
    blue_sendChar('\n');
}

game_end_t check_winner(uint8 board[ROW_SIZE][COL_SIZE], uint8 player) {
    uint32 counter = ZERO;

    for (counter = ZERO; counter < ROW_SIZE; counter++) {
        if ((board[counter][0] == player && board[counter][1] == player && board[counter][2] == player) ||
            (board[0][counter] == player && board[1][counter] == player && board[2][counter] == player)) {
            if (player == 'X')
                return PLAYER_WON;
            else
                return AI_WON;
        }
    }

    if ((board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
        (board[0][2] == player && board[1][1] == player && board[2][0] == player)) {
        if (player == 'X')
            return PLAYER_WON;
        else
            return AI_WON;
    }

    return WAITING;
}

game_end_t check_draw(uint8 board[ROW_SIZE][COL_SIZE]) {
    uint32 row_Counter = ZERO;
    uint32 col_Counter = ZERO;
        
    for (row_Counter = ZERO; row_Counter < ROW_SIZE; row_Counter++) {
        for (col_Counter = ZERO; col_Counter < COL_SIZE; col_Counter++) {
            if (board[row_Counter][col_Counter] == 'N')
                return NOT_DRAW;
        }
    }
    
    return DRAW;
}

void player_move(uint8 board[ROW_SIZE][COL_SIZE], uint8 player) {
    uint32 input = 12;
    
    blue_sendString(" Enter position (1-9) to place ");
    blue_sendChar(player);
    blue_sendString(": ");
    
    while (input == 12) {
        input = blue_getInt();
        
        if (input < 1 || input > 9 || board[(input - 1) / 3][(input - 1) % 3] != 'N') {
            blue_sendString(" Invalid input. Enter position (1-9) to place ");
            blue_sendChar(player);
            blue_sendString(": ");
            input = 12;
        }
    }
    
    uint32 row = (input - 1) / 3;
    uint32 col = (input - 1) % 3;
    
    board[row][col] = player;
}

void ai_move(uint8 board[ROW_SIZE][COL_SIZE], uint8 player) {
	uint32 num_empty_cells = 0;
	uint8 random_move = TRUE;

	for (uint32 i = 0; i < ROW_SIZE; i++) {
		for (uint32 j = 0; j < COL_SIZE; j++) {
			if (board[i][j] == 'N') {
				num_empty_cells++;
			}
		}
	}

	if (num_empty_cells == ROW_SIZE * COL_SIZE) {
		uint32 random_index = rand() % (ROW_SIZE * COL_SIZE);
		uint32 row = random_index / ROW_SIZE;
		uint32 col = random_index % COL_SIZE;
		board[row][col] = player;
		blue_sendString("AI placed ");
		blue_sendChar(player);
		blue_sendString(" at position ");
		blue_sendInt(row * 3 + col + 1);
		blue_sendString("\n");
		random_move = FALSE;
	}

	if (random_move) {
		for (sint32 i = 0; i < ROW_SIZE; i++) {
			for (sint32 j = 0; j < COL_SIZE; j++) {
				if (board[i][j] == 'N') {
					board[i][j] = player;
					if (check_winner(board, player) == AI_WON) {
						blue_sendString("AI placed ");
						blue_sendChar(player);
						blue_sendString(" at position ");
						blue_sendInt(i * 3 + j + 1);
						blue_sendString("\n");
						return;
					}
					board[i][j] = 'N';
				}
			}
		}

		for (sint32 i = 0; i < ROW_SIZE; i++) {
			for (sint32 j = 0; j < COL_SIZE; j++) {
				if (board[i][j] == 'N') {
					board[i][j] = (player == 'X') ? 'O' : 'X';
					if (check_winner(board, (player == 'X') ? 'O' : 'X') == PLAYER_WON) {
						board[i][j] = player;
						blue_sendString("AI placed ");
						blue_sendChar(player);
						blue_sendString(" at position ");
						blue_sendInt(i * 3 + j + 1);
						blue_sendString("\n");
						return;
					}
					board[i][j] = 'N';
				}
			}
		}

		if (board[1][1] == 'N') {
			board[1][1] = player;
			blue_sendString("AI placed ");
			blue_sendChar(player);
			blue_sendString(" at position 5\n");
			return;
		}

		const uint8 corners[4][2] = {{0, 0}, {0, 2}, {2, 0}, {2, 2}};
		for (uint8 k = 0; k < 4; k++) {
			if (board[corners[k][0]][corners[k][1]] == 'N') {
				board[corners[k][0]][corners[k][1]] = player;
				blue_sendString("AI placed ");
				blue_sendChar(player);
				blue_sendString(" at position ");
				blue_sendInt(corners[k][0] * 3 + corners[k][1] + 1);
				blue_sendString("\n");
				return;
			}
		}

		uint32 empty_cells[ROW_SIZE * COL_SIZE];
		num_empty_cells = get_empty_cells(board, empty_cells);
		
		if (num_empty_cells > 0) {
			uint32 random_index = rand() % num_empty_cells;
			uint32 cell = empty_cells[random_index];
			uint32 row = cell / ROW_SIZE;
			uint32 col = cell % COL_SIZE;
			board[row][col] = player;
			blue_sendString("AI placed ");
			blue_sendChar(player);
			blue_sendString(" at position ");
			blue_sendInt(row * 3 + col + 1);
			blue_sendString("\n");
		}
	}
}

uint32 get_empty_cells(uint8 board[ROW_SIZE][COL_SIZE], uint32 *empty_cells) {
    uint32 row_Counter = ZERO;
    uint32 col_Counter = ZERO;
    
    uint32 count = ZERO;
    
    for (row_Counter = ZERO; row_Counter < ROW_SIZE; row_Counter++) {
        for (col_Counter = ZERO; col_Counter < COL_SIZE; col_Counter++) {
            if (board[row_Counter][col_Counter] == 'N') {
                empty_cells[count++] = row_Counter * 3 + col_Counter;
            }
        }
    }
    
    return count;
}

void play_tic() {
	uint8 board[ROW_SIZE][COL_SIZE];
	game_end_t game_status = WAITING;
	uint8 player;

	blue_sendString("Do you want to start first? (Y/N): ");
	uint8 response = blue_getChar();
	while (blue_getChar() != '\n');
	if (response == 'Y' || response == 'y') {
		player = 'X';
		} 
	else {
		player = 'O'; 
	}

	board_init(board);
	
	while (game_status == WAITING) {
		print_board(board);
		
		if (player == 'X') {
			player_move(board, player);
		}
		else {
			ai_move(board, player);
		}
		
		game_status = check_winner(board, player);
		if (game_status != WAITING) {
			break;
		}

		if (check_draw(board) == DRAW) {
			game_status = DRAW;
			break;
		}
		
		player = (player == 'X') ? 'O' : 'X';
	}
	
	print_board(board);
	
	if (game_status == PLAYER_WON) {
		blue_sendString("Congratulations! You won!\n");
		LCD_SendString("You won!");
	}
	else if (game_status == AI_WON) {
		blue_sendString("You lost! AI won!\n");
		LCD_SendString("AI won!");
	}
	else {
		blue_sendString("It's a draw!\n");
		LCD_SendString("Draw!");
	}
}
