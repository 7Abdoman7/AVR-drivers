/*
 * Tic_Blue.h
 *
 * Created: 2/16/2024 2:56:26 PM
 *  Author: Abdo
 */ 

#ifndef _TIK_H_
#define _TIK_H_

#include "../../HAL/BLUETOOTH/Bluetooth.h"
#include "../../HAL/LCD/Lcd.h"

#include <time.h>

#define ROW_SIZE		(3)
#define COL_SIZE		(3)

typedef enum {
	PLAYER_WON,
	AI_WON,
	DRAW,
	NOT_DRAW,
	WAITING
} game_end_t;

void board_init(uint8 board[ROW_SIZE][COL_SIZE]);
void print_board(uint8 board[ROW_SIZE][COL_SIZE]);
game_end_t check_winner(uint8 board[ROW_SIZE][COL_SIZE], uint8 player);
game_end_t check_draw(uint8 board[ROW_SIZE][COL_SIZE]);
void player_move(uint8 board[ROW_SIZE][COL_SIZE], uint8 player);
void ai_move(uint8 board[ROW_SIZE][COL_SIZE], uint8 player);
uint32 get_empty_cells(uint8 board[ROW_SIZE][COL_SIZE], uint32 *empty_cells);
void play_tic();

#endif