/*
 * Bluetooth.c
 *
 * Created: 2/13/2024 9:33:23 PM
 *  Author: Abdo
 */ 

#include "Bluetooth.h"

uint8 blue_getChar() {
	uint8 c = '.';
	c = UART_RxChar();
	
	return c;
}

uint32 blue_getInt() {
	uint32 num = ZERO;
	uint8 c = '.';

	while (TRUE) {
		c = blue_getChar();

		if (c == '\n' || c == '\0' || c == '\r') {
			break;
		}

		if (c >= '0' && c <= '9') {
			num = num * 10 + (c - '0');
		}
	}

	while (blue_getChar() != '\n');

	return num;
}

void blue_sendChar(uint8 c) {
	UART_TxChar(c);
}

void blue_sendString(uint8* str) {
	uint8 counter = ZERO;
	
	for (counter = ZERO; counter < strlen(str); counter++) {
		blue_sendChar(str[counter]);
	}
}

void blue_sendInt(uint32 num) {
	uint8 str[10];
	itoa(num ,str ,10); 
	blue_sendString(str);
}

void blue_clearInputBuffer() {
	UART_clearInputBuffer();
}