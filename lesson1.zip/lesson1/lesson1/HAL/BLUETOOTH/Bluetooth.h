/*
 * Bluetooth.h
 *
 * Created: 2/13/2024 9:32:10 PM
 *  Author: Abdo
 */ 

#ifndef _BLUETOOTH_H_
#define _BLUETOOTH_H_

#include "../../MCAL/UART/uart.h"

uint8 blue_getChar(); 
uint32 blue_getInt(); 

void blue_sendChar(uint8 c); 
void blue_sendString(uint8* str); 
void blue_sendInt(uint32 num); 

#endif
