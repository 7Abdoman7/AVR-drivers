/*
 * Button.c
 *
 * Created: 12/19/2023 10:34:29 PM
 *  Author: CARNIVAL
 */ 
#include "Button.h"

Btn_t btn = {
	BUTTON_PIN,
	IS_RELEASED,
};

Button_State_t Button_Read_State(Btn_t *btn_Pin) {
	if (STD_HIGH == Dio_ReadChannel(btn_Pin->pin)) {
		if (PULL_UP == btn_Pin->pin_state) {
			return IS_RELEASED;
		}
		else if (TRI_STATE == btn_Pin->pin_state) {
			return IS_PRESSED;
		}
	}
	else {
		if (PULL_UP == btn_Pin->pin_state) {
			return IS_PRESSED;
		}
		else if (TRI_STATE == btn_Pin->pin_state){
			return IS_RELEASED;
		}
	}
}

