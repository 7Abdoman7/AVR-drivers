/*
 * Button.h
 *
 * Created: 12/19/2023 10:34:18 PM
 *  Author: CARNIVAL
 */ 
#ifndef HAL_BUTTON_BUTTON_H_
#define HAL_BUTTON_BUTTON_H_

#include "../../MCAL/DIO/Dio.h"
#include "../../MCAL/PORT/Port.h"

#define BUTTON_PIN		NO_USE

typedef enum {
	IS_PRESSED,
	IS_RELEASED
}Button_State_t;

typedef struct {
	DIO_ChannelType pin;
	Pin_State pin_state;
}Btn_t;

Button_State_t Button_Read_State(Btn_t *btn_Pin);

extern Btn_t btn;

#endif /* HAL_BUTTON_BUTTON_H_ */
