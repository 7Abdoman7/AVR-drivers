/*
 * Buzzer.c
 *
 * Created: 12/25/2023 6:56:08 PM
 *  Author: CARNIVAL
 */ 

#include "Buzzer.h"

void Buzzer_Turn_On(DIO_ChannelType buzzer_Pin) {
	Dio_WriteChannel(buzzer_Pin, STD_HIGH);
}

void Buzzer_Turn_Off(DIO_ChannelType buzzer_Pin) {
	Dio_WriteChannel(buzzer_Pin, STD_LOW);
}

void Buzzer_Toggle(DIO_ChannelType buzzer_Pin) {
	Dio_FlipChannel(buzzer_Pin);
}