/*
 * Buzzer.h
 *
 * Created: 12/25/2023 6:55:57 PM
 *  Author: CARNIVAL
 */ 

#ifndef HAL_BUZZER_LED_H_
#define HAL_BUZZER_LED_H_

#include "../../MCAL/DIO/Dio.h"
#include "../../MCAL/PORT/Port.h"

#define BUZZER_PIN		NO_USE

void Buzzer_Turn_On(DIO_ChannelType buzzer_Pin);
void Buzzer_Turn_Off(DIO_ChannelType buzzer_Pin);
void Buzzer_Toggle(DIO_ChannelType buzzer_Pin);

#endif /* HAL_BUZZER_LED_H_ */