/*
 * Joy_stick.c
 *
 * Created: 12/31/2023 11:16:26 PM
 *  Author: CARNIVAL
 */ 
#include "Joy_stick.h"

Joy_stick_state Joy_read() {
	uint32 X = ZERO;
	uint32 Y = ZERO;
	
	X = ADC_Read(VRX);
	Y = ADC_Read(VRY);
	
	if (Y < 14) {
		return UP;
	}
	else if (Y > 1000) {
		return DOWN;
	}
	else if (X < 14) {
		return LEFT;
	}
	else if (X > 1000) {
		return RIGHT;
	}
	else {
		return CENTER;
	}
}
