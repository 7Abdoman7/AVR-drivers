/*
 * Joy_stick.h
 *
 * Created: 12/31/2023 11:16:14 PM
 *  Author: CARNIVAL
 */ 
#ifndef _JOY_STICK_H_
#define _JOY_STICK_H_

#include "../../MCAL/ADC/ADC.h"

#define VRX		NO_USE
#define VRY		NO_USE

typedef enum {
	UP,
	DOWN,
	RIGHT,
	LEFT,
	CENTER,
}Joy_stick_state;

Joy_stick_state Joy_read();

#endif