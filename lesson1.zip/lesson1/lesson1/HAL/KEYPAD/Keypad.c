/*
 * Keypad.c
 *
 * Created: 12/21/2023 7:01:56 PM
 *  Author: CARNIVAL
 */ 

#include "Keypad.h"

#if REAL_KEYPAD
	const uint8 Keypad_Matrix[KEYPAD_ROW_NUM][KEYPAD_COL_NUM] = {
		{'1', '2' ,'3', 'A'},
		{'4', '5', '6', 'B'},
		{'7', '8', '9', 'C'},
		{'*', '0', '#', 'D'}
	};

#else
	const uint8 Keypad_Matrix[KEYPAD_ROW_NUM][KEYPAD_COL_NUM] = {
		{'7', '8' ,'9', '/'},
		{'4', '5', '6', '*'},
		{'1', '2', '3', '-'},
		{'C', '0', '=', '+'}
	};
#endif


Keypad_t keypad = {
	.rows.PortIndex = KEYPAD_ROWS_PORT,
	.rows.mask		= KEYPAD_ROWS_MASK,
	.rows.offset	= KEYPAD_ROWS_OFFSET,

	.cols.PortIndex = KEYPAD_COLS_PORT,
	.cols.mask		= KEYPAD_COLS_MASK,
	.cols.offset	= KEYPAD_COLS_OFFSET,
};

uint8 Keypad_Read() {
	uint8 value = '@';
	uint8 row_Counter = ZERO;
	uint8 col_Bit = ZERO;
	DIO_ChannalGroupLevelType temp = 0x0F;
	DIO_ChannalGroupLevelType col_Level = STD_LOW;
	uint8 stable_count = ZERO;
	uint8 stable_value = ZERO;
	
	for (row_Counter = ZERO; row_Counter < KEYPAD_COL_NUM; row_Counter++) {
		temp = 0x0F;
		CLEAR_BIT(temp, row_Counter);
		Dio_WriteChannelGroup(&(keypad.rows), temp);

		col_Level = Dio_ReadChannelGroup(&(keypad.cols));

		for (col_Bit = ZERO; col_Bit < KEYPAD_COL_NUM; col_Bit++) {
			if (BIT_IS_CLEAR(col_Level, col_Bit)) {
				uint8 stable_count = ZERO;
				uint8 stable_value = Keypad_Matrix[row_Counter][col_Bit];

				while (stable_count < DEBOUNCE_DELAY_MS) {
					col_Level = Dio_ReadChannelGroup(&(keypad.cols));

					if (BIT_IS_CLEAR(col_Level, col_Bit) && stable_value == Keypad_Matrix[row_Counter][col_Bit]) {
						stable_count++;
					} 
					else {
						stable_count = ZERO;
						stable_value = ZERO;
						break;
					}
				}

				if (stable_count >= DEBOUNCE_DELAY_MS) {
					value = stable_value;
					break;
				}
			}
		}
	}

	return value;
}


uint8 Keypad_Get() {
	uint8 value = '@';
	uint8 row_Counter = ZERO;
	uint8 col_Counter = ZERO;
	uint8 col_Bit = ZERO;
	DIO_ChannalGroupLevelType temp = 0x0F;
	DIO_ChannalGroupLevelType col_Level = STD_LOW;
	
	uint8 stable_count = ZERO;
	uint8 stable_value = ZERO;

	while ('@' == value) {
		for (row_Counter = ZERO; row_Counter < KEYPAD_ROW_NUM; row_Counter++) {
			temp = 0x0F;
			CLEAR_BIT(temp, row_Counter);
			Dio_WriteChannelGroup(&(keypad.rows), temp);

			for (col_Counter = ZERO; col_Counter < KEYPAD_COL_NUM; col_Counter++) {
				col_Level = Dio_ReadChannelGroup(&(keypad.cols));
				
				for (col_Bit = ZERO; col_Bit < KEYPAD_COL_NUM; col_Bit++) {
					if (BIT_IS_CLEAR(col_Level, col_Bit)) {
						stable_value = Keypad_Matrix[row_Counter][col_Bit];
						stable_count = ZERO;

						while (stable_count < DEBOUNCE_DELAY_MS) {
							_delay_ms(1);
							col_Level = Dio_ReadChannelGroup(&(keypad.cols));

							if (BIT_IS_CLEAR(col_Level, col_Bit) && stable_value == Keypad_Matrix[row_Counter][col_Bit]) {
								stable_count++;
							} 
							else {
								stable_count = ZERO;
								stable_value = ZERO;
								break;
							}
						}

						if (stable_count >= DEBOUNCE_DELAY_MS) {
							value = stable_value;
							break;
						}
					}
				}
			}
		}
	}
	
	return value;
}