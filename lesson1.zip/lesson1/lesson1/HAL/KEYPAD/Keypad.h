/*
 * Keypad.h
 *
 * Created: 12/21/2023 7:01:30 PM
 *  Author: CARNIVAL
 */ 

#ifndef HAL_KEYPAD_KEYPAD_H_
#define HAL_KEYPAD_KEYPAD_H_

#include "Keypad_cfg.h"

uint8 Keypad_Read();
uint8 Keypad_Get();

#endif /* HAL_KEYPAD_KEYPAD_H_ */

