/*
 * Keypad_cfg.h
 *
 * Created: 12/21/2023 7:01:45 PM
 *  Author: CARNIVAL
 */ 

#ifndef HAL_KEYPAD_KEYPAD_CFG_H_
#define HAL_KEYPAD_KEYPAD_CFG_H_

#include "../../MCAL/DIO/Dio.h"
#include "../../MCAL/PORT/Port.h"

#define KEYPAD_ROWS_PORT		NO_USE
#define KEYPAD_ROWS_MASK		NO_USE
#define KEYPAD_ROWS_OFFSET		NO_USE

#define KEYPAD_COLS_PORT		NO_USE
#define KEYPAD_COLS_MASK		NO_USE
#define KEYPAD_COLS_OFFSET		NO_USE

#define REAL_KEYPAD				(0)

#define	KEYPAD_ROW_NUM			(4)
#define	KEYPAD_COL_NUM			(4)

#define DEBOUNCE_DELAY_MS		(15)

typedef struct {
	DIO_ChannelGroupType rows;
	DIO_ChannelGroupType cols;
}Keypad_t;

extern Keypad_t keypad;

#endif /* HAL_KEYPAD_KEYPAD_CFG_H_ */

