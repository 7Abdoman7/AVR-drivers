/*
 * Lcd.c
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */
#include "Lcd.h"

LCD_t LCD = {
	.RS 	= LCD_RS_PIN,
	.EN 	= LCD_EN_PIN,

	.Data.PortIndex = LCD_DATA_PORT,
	.Data.mask 		= LCD_DATA_MASK,
	.Data.offset	= LCD_DATA_OFFSET,
};

void LCD_command(const uint8 cmd) {
	Dio_WriteChannel(LCD.RS, STD_LOW);
	Dio_WriteChannel(LCD.EN, STD_HIGH);

	DIO_ChannalGroupLevelType cmdHigh = cmd >> HIGH_MASK;

	Dio_WriteChannelGroup(&(LCD.Data), cmdHigh);

	Dio_WriteChannel(LCD.EN, STD_HIGH);
	_delay_ms(1);

	Dio_WriteChannel(LCD.EN, STD_LOW);
	_delay_ms(1);

	Dio_WriteChannelGroup(&(LCD.Data), cmd);

	Dio_WriteChannel(LCD.EN, STD_HIGH);
	_delay_ms(1);

	Dio_WriteChannel(LCD.EN, STD_LOW);
	_delay_ms(1);
}

void LCD_SendChar(const uint8 data) {
	Dio_WriteChannel(LCD.RS, STD_HIGH);
	DIO_ChannalGroupLevelType dataHigh = data >> HIGH_MASK;

	Dio_WriteChannelGroup(&(LCD.Data), dataHigh);

	Dio_WriteChannel(LCD.EN, STD_HIGH);
	_delay_ms(1);

	Dio_WriteChannel(LCD.EN, STD_LOW);
	_delay_ms(1);

	Dio_WriteChannelGroup(&(LCD.Data), data);

	Dio_WriteChannel(LCD.EN, STD_HIGH);
	_delay_ms(1);

	Dio_WriteChannel(LCD.EN, STD_LOW);
	_delay_ms(1);
}

void LCD_SendString(const uint8 *str) {
	while (*str) {
		LCD_SendChar(*str++);
	}
}

void LCD_SendString_XY(const uint8 *str, const uint8 row, const uint8 col) {
    uint8 position = ZERO;

    if (row == FIRST_ROW) {
        position = 0x80 + col;
    }
    else if (row == SECOND_ROW) {
        position = 0xC0 + col;
    }

    LCD_command(position);
    LCD_SendString(str);
}

void LCD_SendNumber(const sint32 number) {
    uint8 buffer[20];

    itoa(number, buffer, 10);
    LCD_SendString(buffer);
}

void LCD_SendFloat(const float32 number) {
	uint8 buffer[20];
	sprintf(buffer, "%f", (double)number);  
	LCD_SendString(buffer);
}

void LCD_init() {
	LCD_command(0x02);
	_delay_ms(4);

	LCD_command(0x28);
	_delay_us(100);

	LCD_command(0x0C);
	_delay_us(100);
}




