/*
 * Lcd.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef HAL_LCD_LCD_H_
#define HAL_LCD_LCD_H_

#include "Lcd_cfg.h"

void LCD_command(const uint8 cmd);
void LCD_SendChar(const uint8 data);
void LCD_SendString(const uint8* str);
void LCD_SendString_XY(const uint8* str, const uint8 row, const uint8 col);
void LCD_SendNumber(const sint32 number);
void LCD_SendFloat(const float32 number);
void LCD_init();

#endif /* HAL_LCD_LCD_H_ */
