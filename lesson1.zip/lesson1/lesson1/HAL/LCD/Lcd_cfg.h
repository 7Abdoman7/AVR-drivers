/*
 * Lcd.cfg.h
 *
 *  Created on: Oct 30, 2023
 *      Author: CARNIVAL
 */

#ifndef HAL_LCD_LCD_CFG_H_
#define HAL_LCD_LCD_CFG_H_

#include "../../MCAL/DIO/Dio.h"
#include "../../MCAL/PORT/Port.h"

#define	LCD_RS_PIN			NO_USE
#define LCD_EN_PIN			NO_USE
#define LCD_DATA_PORT		NO_USE
#define LCD_DATA_MASK		NO_USE
#define LCD_DATA_OFFSET		NO_USE

#define	FIRST_ROW			(1)
#define SECOND_ROW			(2)

#define FIRST_COL        	(0)
#define SECOND_COL       	(1)
#define THIRD_COL        	(2)
#define FOURTH_COL       	(3)
#define FIFTH_COL        	(4)
#define SIXTH_COL        	(5)
#define SEVENTH_COL      	(6)
#define EIGHTH_COL       	(7)
#define NINTH_COL        	(8)
#define TENTH_COL        	(9)
#define ELEVENTH_COL     	(10)
#define TWELFTH_COL      	(11)
#define THIRTEENTH_COL   	(12)
#define FOURTEENTH_COL   	(13)
#define FIFTEENTH_COL    	(14)
#define SIXTEENTH_COL    	(15)

#define	HIGH_MASK			(4)

/*============================ LCD COMMANDS =============================*/
#define CLEAR_SCREEN		0x01
#define RETURN_HOME			0x02
#define DECREMENT_CURSOR	0x04
#define INCREMENT_CURSOR	0x06
#define SHIFT_CURSOR_LEFT	0x10
#define SHIFT_CURSOR_RIGHT	0x14
#define CURSOR_BEGIN_LINE1	0x80
#define CURSOR_BEGIN_LINE2	0xC0

typedef struct {
	DIO_ChannelType RS;
	DIO_ChannelType EN;
	DIO_ChannelGroupType Data;
}LCD_t;

extern LCD_t LCD;

#endif /* HAL_LCD_LCD_CFG_H_ */
