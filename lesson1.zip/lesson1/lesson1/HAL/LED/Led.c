/*
 * Led.c
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */
#include "Led.h"

void Led_Turn_On(DIO_ChannelType led_Pin) {
	Dio_WriteChannel(led_Pin, STD_HIGH);
}

void Led_Turn_Off(DIO_ChannelType led_Pin) {
	Dio_WriteChannel(led_Pin, STD_LOW);
}

void Led_Toggle(DIO_ChannelType led_Pin) {
	Dio_FlipChannel(led_Pin);
}

