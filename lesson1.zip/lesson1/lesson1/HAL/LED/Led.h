/*
 * Led.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef HAL_LED_LED_H_
#define HAL_LED_LED_H_

#include "../../MCAL/DIO/Dio.h"
#include "../../MCAL/PORT/Port.h"

#define LED_PIN		NO_USE

void Led_Turn_On(DIO_ChannelType led_Pin);
void Led_Turn_Off(DIO_ChannelType led_Pin);
void Led_Toggle(DIO_ChannelType led_Pin);

#endif /* HAL_LED_LED_H_ */
