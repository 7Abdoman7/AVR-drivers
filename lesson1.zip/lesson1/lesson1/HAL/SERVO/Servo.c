/*
 * Servo.c
 *
 * Created: 2/18/2024 10:09:54 AM
 *  Author: Abdo
 */ 

#include "Servo.h"

uint16 servo_angle = 90;

void servo_init() {  
	SET_BIT(TCCR1A, COM1A1);  
	SET_BIT(TCCR1A, WGM11);
	SET_BIT(TCCR1B, WGM12);
	SET_BIT(TCCR1B, WGM13);
	SET_BIT(TCCR1B, CS11);
	
	ICR1 = 27647;
	TCNT1 = 0;
	
	OCR1A = 160;
}
			
void servo_move(uint16 angle) {
	uint16 input = (uint16)(((float)angle / 180.0) * (280 - 65) + 65);
	OCR1A = input;
	
	servo_angle = angle;
	
	_delay_us(50); 
}

uint8 servo_GetAngle() {
	return servo_angle;
}

