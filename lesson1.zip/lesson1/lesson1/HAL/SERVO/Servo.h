/*
 * Servo.h
 *
 * Created: 2/18/2024 10:10:12 AM
 *  Author: Abdo
 */ 

#ifndef _SERVO_H_
#define _SERVO_H_

#include "../../MCAL/TIMER1/Timer1.h"

void servo_init();
void servo_move(uint16 angle);
uint8 servo_GetAngle();

extern uint16 servo_angle;

#endif