/*
 * Ultrasonic.c
 *
 * Created: 2/17/2024 10:04:49 PM
 *  Author: Abdo
 */ 

#include "Ultrasonic.h"

uint32 TimerOverflow = ZERO;

double64 ultrasonic_getDistance() {
	uint32 count = ZERO;
	double64 distance = ZERO;
	
	sei();		
	
	SET_BIT(TIMSK, TOIE1);		
	TCCR1A = ZERO;		

	SET_BIT(TRIGGER_PORT, TRIGGER_PIN);
	_delay_us(10);
	CLEAR_BIT(TRIGGER_PORT, TRIGGER_PIN);
		
	TCNT1 = ZERO;	
	TCCR1B = 0x41;	
	TIFR = 1 << ICF1;	
	TIFR = 1 << TOV1;	
		
	while (BIT_IS_CLEAR(TIFR, ICF1));
		
	TCNT1 = ZERO;
	TCCR1B = 0x01;	
	TIFR = 1 << ICF1;	
	TIFR = 1 << TOV1;	
		
	TimerOverflow = ZERO;

	while (BIT_IS_CLEAR(TIFR, ICF1));
		
	count = ICR1 + (65535 * TimerOverflow);	
	distance = (double64)count / 55;

	_delay_ms(200);
	
	return distance;
}

Obstacle_state_t ultrasonic_obstacleDetected() {
	double64 distance = ultrasonic_getDistance();
	
	if (distance <= OBSTACLE_THRESHOLD) {
		return EXIST; 
	} 
	else {
		return NOT_EXIST; 
	}
}


ISR(TIMER1_OVF_vect) {
	TimerOverflow++;
}