/*
 * Ultrasonic.h
 *
 * Created: 2/17/2024 10:04:41 PM
 *  Author: Abdo
 */ 

#ifndef _ULTRA_H_
#define _ULTRA_H_

#include "../../MCAL/TIMER1/Timer1.h"
#include "../../MCAL/INTERRUPT/Interrupt.h"

#define TRIGGER_PIN				(7)
#define TRIGGER_PORT			PORTD
#define OBSTACLE_THRESHOLD		5 

typedef enum {
	EXIST,
	NOT_EXIST
} Obstacle_state_t;

double64 ultrasonic_getDistance();
Obstacle_state_t ultrasonic_obstacleDetected();

#endif

	

