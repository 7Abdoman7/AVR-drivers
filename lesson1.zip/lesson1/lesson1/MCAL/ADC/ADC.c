/*
 * ADC.c
 *
 * Created: 12/27/2023 2:28:36 PM
 *  Author: CARNIVAL
 */ 

#include "ADC.h"

void ADC_Init() {
	SET_BIT(ADCSRA, ADEN);
	SET_BIT(ADCSRA, ADPS0);
	SET_BIT(ADCSRA, ADPS1);
	SET_BIT(ADCSRA, ADPS2);
	
	SET_BIT(ADMUX, REFS0);
}

uint32 ADC_Read(DIO_ChannelType channel) {
	channel = channel & 0b00000111;
	ADMUX = (ADMUX & 0xF8) | channel;
	
	SET_BIT(ADCSRA, ADSC);
	while (BIT_IS_SET(ADCSRA, ADSC));
	
	return (uint32)(ADCL | (ADCH << 8));
}




