/*
 * ADC.h
 *
 * Created: 12/27/2023 2:28:28 PM
 *  Author: CARNIVAL
 */ 

#ifndef _ADC_H_
#define _ADC_H_

#include "../utilities/Utilities.h"
#include "../DIO/Dio_types.h"

void ADC_Init();
uint32 ADC_Read(DIO_ChannelType channel);

#endif /* _ADC_H_ */