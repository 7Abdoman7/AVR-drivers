/*
 * Dio.c
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */
#include "Dio.h"

DIO_PortLevelType Dio_ReadPort(DIO_PortType PortId) {
	DIO_PortLevelType port_Level = STD_LOW;

	switch (PortId) {
		case DIO_PORTA:
			port_Level = PINA;
			break;
		case DIO_PORTB:
			port_Level = PINB;
			break;
		case DIO_PORTC:
			port_Level = PINC;
			break;
		case DIO_PORTD:
			port_Level = PIND;
			break;
		default:
			break;
	}

	return port_Level;
}

void Dio_WritePort(DIO_PortType PortId, DIO_PortLevelType Level) {
	switch (PortId) {
		case DIO_PORTA:
			PORTA = Level;
			break;
		case DIO_PORTB:
			PORTB = Level;
			break;
		case DIO_PORTC:
			PORTC = Level;
			break;
		case DIO_PORTD:
			PORTD = Level;
			break;
		default:
			break;
	}
}

DIO_ChannalLevelType Dio_ReadChannel(DIO_ChannelType ChannelId) {
	DIO_ChannalLevelType level = STD_LOW;

	DIO_PortType port = ChannelId / PIN_PORT_NUM;
	DIO_ChannelType pin = ChannelId % PIN_PORT_NUM;

	switch (port) {
		case DIO_PORTA:
			level = READ_BIT(PINA, pin);
			break;
		case DIO_PORTB:
			level = READ_BIT(PINB, pin);
			break;
		case DIO_PORTC:
			level = READ_BIT(PINC, pin);
			break;
		case DIO_PORTD:
			level = READ_BIT(PIND, pin);
			break;
		default:
			break;
	}

	return level;
}

void Dio_WriteChannel(DIO_ChannelType ChannelId, DIO_ChannalLevelType Level) {
	DIO_PortType port = ChannelId / PIN_PORT_NUM;
	DIO_ChannelType pin = ChannelId % PIN_PORT_NUM;

	if (STD_HIGH == Level) {
		switch (port) {
			case DIO_PORTA:
				SET_BIT(PORTA, pin);
				break;
			case DIO_PORTB:
				SET_BIT(PORTB, pin);
				break;
			case DIO_PORTC:
				SET_BIT(PORTC, pin);
				break;
			case DIO_PORTD:
				SET_BIT(PORTD, pin);
				break;
			default:
				break;
		}
	}
	else if (STD_LOW == Level) {
		switch (port) {
			case DIO_PORTA:
				CLEAR_BIT(PORTA, pin);
				break;
			case DIO_PORTB:
				CLEAR_BIT(PORTB, pin);
				break;
			case DIO_PORTC:
				CLEAR_BIT(PORTC, pin);
				break;
			case DIO_PORTD:
				CLEAR_BIT(PORTD, pin);
				break;
			default:
				break;
		}
	}
}

DIO_ChannalLevelType Dio_FlipChannel(DIO_ChannelType ChannelId) {
	DIO_ChannalLevelType level = STD_LOW;
	DIO_PortType port = ChannelId / PIN_PORT_NUM;
	DIO_ChannelType pin = ChannelId % PIN_PORT_NUM;

	switch (port) {
		case DIO_PORTA:
			TOGGLE_BIT(PORTA, pin);
			break;
		case DIO_PORTB:
			TOGGLE_BIT(PORTB, pin);
			break;
		case DIO_PORTC:
			TOGGLE_BIT(PORTC, pin);
			break;
		case DIO_PORTD:
			TOGGLE_BIT(PORTD, pin);
			break;
		default:
			break;
	}

	level = Dio_ReadChannel(ChannelId);

	return level;
}

DIO_ChannalGroupLevelType Dio_ReadChannelGroup(DIO_ChannelGroupType *ChannelGroupId) {
	DIO_PortType portIndex			= ChannelGroupId->PortIndex;
	uint8 mask 						= ChannelGroupId->mask;
	uint8 offset 					= ChannelGroupId->offset;

	DIO_PortLevelType level         = Dio_ReadPort(portIndex);
	level = (level & mask) >> (offset);

	return level;
}

void Dio_WriteChannelGroup(DIO_ChannelGroupType *ChannelGroupId, DIO_ChannalGroupLevelType Level) {
	DIO_PortType portIndex  	= ChannelGroupId->PortIndex;
	DIO_PortLevelType level2    = Dio_ReadPort(portIndex);
	uint8 mask 				    = ChannelGroupId->mask;
	uint8 offset 			    = ChannelGroupId->offset;

	level2 &= ~mask;
	level2 |= ((Level << offset) & mask);
	Dio_WritePort(portIndex, level2);
}

DIO_ChannalGroupLevelType Dio_FlipChannelGroup(DIO_ChannelGroupType *ChannelGroupId) {
	DIO_ChannalGroupLevelType level = STD_LOW;

	DIO_PortType portIndex	= ChannelGroupId->PortIndex;
	DIO_PortLevelType port 	= Dio_ReadPort(portIndex);
	uint8 mask 				= ChannelGroupId->mask;
	uint8 offset 			= ChannelGroupId->offset;

	port = (port & mask) >> (offset);
	Dio_WriteChannelGroup(ChannelGroupId, port);
	level = Dio_ReadChannelGroup(ChannelGroupId);

	return level;
}
