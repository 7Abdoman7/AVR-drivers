/*
 * Dio.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_DIO_DIO_H_
#define MCAL_DIO_DIO_H_

#include "../utilities/Utilities.h"
#include "Dio_types.h"

DIO_PortLevelType Dio_ReadPort(DIO_PortType PortId);
void Dio_WritePort(DIO_PortType PortId, DIO_PortLevelType Level);

DIO_ChannalLevelType Dio_ReadChannel(DIO_ChannelType ChannelId);
void Dio_WriteChannel(DIO_ChannelType ChannelId, DIO_ChannalLevelType Level);
DIO_ChannalLevelType Dio_FlipChannel(DIO_ChannelType ChannelId);

DIO_ChannalGroupLevelType Dio_ReadChannelGroup(DIO_ChannelGroupType *ChannelGroupId);
void Dio_WriteChannelGroup(DIO_ChannelGroupType *ChannelGroupId, DIO_ChannalGroupLevelType Level);
DIO_ChannalGroupLevelType Dio_FlipChannelGroup(DIO_ChannelGroupType *ChannelGroupId);

#endif /* MCAL_DIO_DIO_H_ */
