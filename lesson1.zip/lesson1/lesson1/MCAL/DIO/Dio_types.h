/*
 * Dio_types.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_DIO_DIO_TYPES_H_
#define MCAL_DIO_DIO_TYPES_H_

#define PIN_PORT_NUM	(8)

typedef uint8 DIO_PortLevelType;
typedef uint8 DIO_ChannalLevelType;
typedef uint8 DIO_ChannalGroupLevelType;

typedef enum {
	DIO_PORTA,
	DIO_PORTB,
	DIO_PORTC,
	DIO_PORTD
}DIO_PortType;

typedef enum {
	P_A0,
	P_A1,
	P_A2,
	P_A3,
	P_A4,
	P_A5,
	P_A6,
	P_A7,
	P_B0,
	P_B1,
	P_B2,
	P_B3,
	P_B4,
	P_B5,
	P_B6,
	P_B7,
	P_C0,
	P_C1,
	P_C2,
	P_C3,
	P_C4,
	P_C5,
	P_C6,
	P_C7,
	P_D0,
	P_D1,
	P_D2,
	P_D3,
	P_D4,
	P_D5,
	P_D6,
	P_D7
}DIO_ChannelType;

typedef struct {
  uint8 mask;
  uint8 offset;
  DIO_PortType PortIndex;
}DIO_ChannelGroupType;


#endif /* MCAL_DIO_DIO_TYPES_H_ */
