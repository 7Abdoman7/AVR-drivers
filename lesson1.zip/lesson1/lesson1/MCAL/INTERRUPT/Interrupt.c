/*
 * Interrupt.c
 *
 * Created: 1/3/2024 1:29:10 PM
 *  Author: CARNIVAL
 */ 

#include "Interrupt.h"

static void init_MCUCR_INT0() {
	switch (MCUCR_STATE_INT0) {
		case FALLING_EDGE:
			CLEAR_BIT(MCUCR, ISC00);
			SET_BIT(MCUCR, ISC01);
		break;
		case RISING_EDGE:
			SET_BIT(MCUCR, ISC00);
			SET_BIT(MCUCR, ISC01);
		break;
		case BOTH:
			SET_BIT(MCUCR, ISC00);
			CLEAR_BIT(MCUCR, ISC01);
		break;
		case LOW:
			CLEAR_BIT(MCUCR, ISC00);
			CLEAR_BIT(MCUCR, ISC01);
		break;
	}
}

static void init_MCUCR_INT1() {
	switch (MCUCR_STATE_INT1) {
		case FALLING_EDGE:
			CLEAR_BIT(MCUCR, ISC10);
			SET_BIT(MCUCR, ISC11);
		break;
		case RISING_EDGE:
			SET_BIT(MCUCR, ISC10);
			SET_BIT(MCUCR, ISC11);
		break;
		case BOTH:
			SET_BIT(MCUCR, ISC10);
			CLEAR_BIT(MCUCR, ISC11);
		break;
		case LOW:
			CLEAR_BIT(MCUCR, ISC10);
			CLEAR_BIT(MCUCR, ISC11);
		break;
	}
}

void Init_INT0() {
	sei();
	init_MCUCR_INT0();
	SET_BIT(GICR, INT0);
}

void Init_INT1() {
	sei();
	init_MCUCR_INT1();
	
	SET_BIT(GICR, INT1);
}