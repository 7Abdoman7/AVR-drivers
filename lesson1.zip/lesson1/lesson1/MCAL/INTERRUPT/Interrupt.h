/*
 * Interrupt.h
 *
 * Created: 1/3/2024 1:28:58 PM
 *  Author: CARNIVAL
 */ 

#ifndef _INTERRUPT_H_
#define _INTERRUPT_H_

#include "avr/interrupt.h"
#include "../utilities/Utilities.h"

typedef enum {
	FALLING_EDGE,
	RISING_EDGE,
	BOTH,
	LOW,
}MCUCR_state_t;

#define MCUCR_STATE_INT0			(BOTH)
#define MCUCR_STATE_INT1			(LOW)

void Init_INT0();
void Init_INT1();

#endif