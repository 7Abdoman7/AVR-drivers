/*
 * Port.c
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#include "Port.h"

const Pin_Direction Port_cfg[PORT_NUM][PIN_PORT_NUM] = {
		{P_A0_DIR, P_A1_DIR, P_A2_DIR, P_A3_DIR, P_A4_DIR, P_A5_DIR, P_A6_DIR, P_A7_DIR},
		{P_B0_DIR, P_B1_DIR, P_B2_DIR, P_B3_DIR, P_B4_DIR, P_B5_DIR, P_B6_DIR, P_B7_DIR},
		{P_C0_DIR, P_C1_DIR, P_C2_DIR, P_C3_DIR, P_C4_DIR, P_C5_DIR, P_C6_DIR, P_C7_DIR},
		{P_D0_DIR, P_D1_DIR, P_D2_DIR, P_D3_DIR, P_D4_DIR, P_D5_DIR, P_D6_DIR, P_D7_DIR}
};

const Pin_State Port_cfg_State[PORT_NUM][PIN_PORT_NUM] = {
		{P_A0_STATE, P_A1_STATE, P_A2_STATE, P_A3_STATE, P_A4_STATE, P_A5_STATE, P_A6_STATE, P_A7_STATE},
		{P_B0_STATE, P_B1_STATE, P_B2_STATE, P_B3_STATE, P_B4_STATE, P_B5_STATE, P_B6_STATE, P_B7_STATE},
		{P_C0_STATE, P_C1_STATE, P_C2_STATE, P_C3_STATE, P_C4_STATE, P_C5_STATE, P_C6_STATE, P_C7_STATE},
		{P_D0_STATE, P_D1_STATE, P_D2_STATE, P_D3_STATE, P_D4_STATE, P_D5_STATE, P_D6_STATE, P_D7_STATE}
};

void Port_Init() {
	uint16 counter_Port = ZERO;
	uint16 counter_Pin 	= ZERO;

	for (counter_Port = ZERO; counter_Port < PORT_NUM; counter_Port++) {
		for (counter_Pin = ZERO; counter_Pin < PIN_PORT_NUM; counter_Pin++) {
			if (PIN_OUTPUT == Port_cfg[counter_Port][counter_Pin]) {
				switch (counter_Port) {
					case 0:
						SET_BIT(DDRA, counter_Pin);
						break;
					case 1:
						SET_BIT(DDRB, counter_Pin);
						break;
					case 2:
						SET_BIT(DDRC, counter_Pin);
						break;
					case 3:
						SET_BIT(DDRD, counter_Pin);
						break;
				}
			}
			else if (PIN_INPUT == Port_cfg[counter_Port][counter_Pin]) {
				switch (counter_Port) {
					case 0:
						CLEAR_BIT(DDRA, counter_Pin);
						break;
					case 1:
						CLEAR_BIT(DDRB, counter_Pin);
						break;
					case 2:
						CLEAR_BIT(DDRC, counter_Pin);
						break;
					case 3:
						CLEAR_BIT(DDRD, counter_Pin);
						break;
				}
			}
			else {

			}
			
			if (PULL_UP == Port_cfg_State[counter_Port][counter_Pin]) {
				switch (counter_Port) {
					case 0:
						SET_BIT(PORTA, counter_Pin);
					break;
					case 1:
						SET_BIT(PORTB, counter_Pin);
					break;
					case 2:
						SET_BIT(PORTC, counter_Pin);
					break;
					case 3:
						SET_BIT(PORTD, counter_Pin);
					break;
				}
			}
			else if (TRI_STATE == Port_cfg_State[counter_Port][counter_Pin]) {
				switch (counter_Port) {
					case 0:
						CLEAR_BIT(PORTA, counter_Pin);
					break;
					case 1:
						CLEAR_BIT(PORTB, counter_Pin);
					break;
					case 2:
						CLEAR_BIT(PORTC, counter_Pin);
					break;
					case 3:
						CLEAR_BIT(PORTD, counter_Pin);
					break;
				}
			}
			else {

			}
		}
	}
}
