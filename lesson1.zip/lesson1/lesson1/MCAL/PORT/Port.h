/*
 * Port.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_PORT_PORT_H_
#define MCAL_PORT_PORT_H_

#include "../utilities/Utilities.h"
#include "Port_cfg.h"

void Port_Init();

#endif /* MCAL_PORT_PORT_H_ */
