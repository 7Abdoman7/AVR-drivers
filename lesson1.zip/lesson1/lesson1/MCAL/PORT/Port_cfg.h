/*
 * Port_cfg.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_PORT_PORT_CFG_H_
#define MCAL_PORT_PORT_CFG_H_

#define	PIN_PORT_NUM		(8)
#define	PORT_NUM			(4)

typedef enum {
	PIN_INPUT,
	PIN_OUTPUT,
}Pin_Direction;

typedef enum {
	PULL_UP,
	TRI_STATE,
}Pin_State;

#define P_A0_DIR	PIN_INPUT
#define P_A1_DIR	NO_USE
#define P_A2_DIR	NO_USE
#define P_A3_DIR	NO_USE
#define P_A4_DIR	NO_USE
#define P_A5_DIR	NO_USE
#define P_A6_DIR	NO_USE
#define P_A7_DIR	NO_USE

#define P_B0_DIR	NO_USE
#define P_B1_DIR	NO_USE
#define P_B2_DIR	NO_USE
#define P_B3_DIR	NO_USE
#define P_B4_DIR	NO_USE
#define P_B5_DIR	NO_USE
#define P_B6_DIR	NO_USE
#define P_B7_DIR	NO_USE

#define P_C0_DIR	NO_USE
#define P_C1_DIR	NO_USE
#define P_C2_DIR	NO_USE
#define P_C3_DIR	NO_USE
#define P_C4_DIR	NO_USE
#define P_C5_DIR	NO_USE
#define P_C6_DIR	NO_USE
#define P_C7_DIR	NO_USE

#define P_D0_DIR	NO_USE
#define P_D1_DIR	NO_USE
#define P_D2_DIR	NO_USE
#define P_D3_DIR	NO_USE
#define P_D4_DIR	NO_USE
#define P_D5_DIR	NO_USE
#define P_D6_DIR	NO_USE
#define P_D7_DIR	PIN_INPUT


#define P_A0_STATE	PULL_UP
#define P_A1_STATE	NO_USE
#define P_A2_STATE	NO_USE
#define P_A3_STATE	NO_USE
#define P_A4_STATE	NO_USE
#define P_A5_STATE	NO_USE
#define P_A6_STATE	NO_USE
#define P_A7_STATE	NO_USE

#define P_B0_STATE	NO_USE
#define P_B1_STATE	NO_USE
#define P_B2_STATE	NO_USE
#define P_B3_STATE	NO_USE
#define P_B4_STATE	NO_USE
#define P_B5_STATE	NO_USE
#define P_B6_STATE	NO_USE
#define P_B7_STATE	NO_USE

#define P_C0_STATE	NO_USE
#define P_C1_STATE	NO_USE
#define P_C2_STATE	NO_USE
#define P_C3_STATE	NO_USE
#define P_C4_STATE	NO_USE
#define P_C5_STATE	NO_USE
#define P_C6_STATE	NO_USE
#define P_C7_STATE	NO_USE

#define P_D0_STATE	NO_USE
#define P_D1_STATE	NO_USE
#define P_D2_STATE	NO_USE
#define P_D3_STATE	NO_USE
#define P_D4_STATE	NO_USE
#define P_D5_STATE	NO_USE
#define P_D6_STATE	NO_USE
#define P_D7_STATE	NO_USE

#endif /* MCAL_PORT_PORT_CFG_H_ */
