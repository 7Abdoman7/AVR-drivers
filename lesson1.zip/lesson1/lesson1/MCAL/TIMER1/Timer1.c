/*
 * Timers.c
 *
 * Created: 2/17/2024 9:28:55 PM
 *  Author: Abdo
 */ 

#include "Timer1.h"

void timer1_init(uint32 OCR1A_data) {
	TCCR1A = ZERO;      
	SET_BIT(TCCR1B, WGM12);
	SET_BIT(TCCR1B, CS10);     
	
	OCR1A = 19999;              

	TIMSK |= (1 << OCIE1A);
}
