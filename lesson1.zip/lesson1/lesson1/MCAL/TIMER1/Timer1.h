/*
 * Timers.h
 *
 * Created: 2/17/2024 9:28:50 PM
 *  Author: Abdo
 */ 

#ifndef _TIMER1_H_
#define _TIMER1_H_

#include "../utilities/Utilities.h"
#include "../DIO/Dio.h"

void timer1_init();

#endif 
