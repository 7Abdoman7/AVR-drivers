/*
 * uart.c
 *
 * Created: 2/13/2024 9:05:40 PM
 *  Author: Abdo
 */ 
#include "uart.h"

void UART_init() {	
	uint8 baud = ((F_CPU / 8) / USART_BAUDRATE) - 1;
		
	SET_BIT(UCSRA, U2X);
	
	SET_BIT(UCSRB, RXEN);
	SET_BIT(UCSRB, TXEN);
	
	UCSRC |= (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1);
	
	UBRRL = baud;
	UBRRH = (baud >> 8);
}

data_available_t Data_avail_Check_RX() {
	if (BIT_IS_SET(UCSRA, RXC)) {
		return READY;
	}
	else {
		return NOT_READY;
	}
}

data_available_t Data_avail_Check_TX() {
	if (BIT_IS_SET(UCSRA, UDRE)) {
		return READY;
	}
	else {
		return NOT_READY;
	}
}

uint8 UART_RxChar() {
	while (NOT_READY == Data_avail_Check_RX());
	return UDR;		
}

void UART_TxChar(uint8 c) {
	while (NOT_READY == Data_avail_Check_TX());
	UDR = c;
}

void UART_clearInputBuffer() {
	while (Data_avail_Check_RX() == READY) {
		UART_RxChar(); 
	}
}

