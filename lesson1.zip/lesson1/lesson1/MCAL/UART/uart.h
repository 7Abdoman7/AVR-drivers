/*
 * uart.h
 *
 * Created: 2/13/2024 9:05:31 PM
 *  Author: Abdo
 */ 

#ifndef _UART_H_
#define _UART_h_

#include "../utilities/Utilities.h"

#define USART_BAUDRATE		(9600)

typedef enum {
	READY,
	NOT_READY,
} data_available_t;

void UART_init();
data_available_t Data_avail_Check_TX(); 
data_available_t Data_avail_Check_RX();
uint8 UART_RxChar();
void UART_TxChar(uint8 c);
void UART_clearInputBuffer();

#endif