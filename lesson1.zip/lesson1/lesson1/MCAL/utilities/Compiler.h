/*
 * Compiler.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_UTILITIES_COMPILER_H_
#define MCAL_UTILITIES_COMPILER_H_

#define	F_CPU		(11059200)

#include <avr/io.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <util/delay.h>

#endif /* MCAL_UTILITIES_COMPILER_H_ */
