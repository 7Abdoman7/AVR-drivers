/*
 * Platform_Types.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_UTILITIES_PLATFORM_TYPES_H_
#define MCAL_UTILITIES_PLATFORM_TYPES_H_

typedef unsigned char 	uint8;
typedef signed char		sint8;

typedef unsigned short 	uint16;
typedef signed short 	sint16;

typedef unsigned long 	uint32;
typedef signed long 	sint32;

typedef float 			float32;
typedef double 			double64;

#endif /* MCAL_UTILITIES_PLATFORM_TYPES_H_ */
