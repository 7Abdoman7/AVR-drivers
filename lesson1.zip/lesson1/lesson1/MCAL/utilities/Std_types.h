/*
 * Std_Types.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_UTILITIES_STD_TYPES_H_
#define MCAL_UTILITIES_STD_TYPES_H_

#include "Platform_Types.h"

typedef	uint8 Std_ReturnType;

#ifndef NULL
#define NULL			0x00
#endif

#define STD_HIGH        0x01
#define STD_LOW         0x00

#define STD_ACTIVE      0x01
#define STD_IDLE        0x00
#define STD_ON          0x01
#define STD_OFF         0x00

#define E_OK            ((Std_ReturnType)0x00)
#define E_NOT_OK        ((Std_ReturnType)0x01)

#define FALSE			0x00
#define TRUE			0x01

#define ZERO			0x00
#define NO_USE			0

#endif /* MCAL_UTILITIES_STD_TYPES_H_ */
