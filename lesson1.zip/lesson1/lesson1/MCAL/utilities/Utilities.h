/*
 * Utilities.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MCAL_UTILITIES_UTILITIES_H_
#define MCAL_UTILITIES_UTILITIES_H_

#include "Common_Macros.h"
#include "Compiler.h"
#include "Platform_Types.h"
#include "Std_Types.h"

#endif /* MCAL_UTILITIES_UTILITIES_H_ */
