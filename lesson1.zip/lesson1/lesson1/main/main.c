/*
 * main.c
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */
#include "main.h"

void task_init() {
	Port_Init();
}

int main() {
	task_init();
	
	while(1) {
	}
	
	return 0;
}

