/*
 * main.h
 *
 *  Created on: Oct 25, 2023
 *      Author: CARNIVAL
 */

#ifndef MAIN_MAIN_H_
#define MAIN_MAIN_H_

void task_init();

#endif /* MAIN_MAIN_H_ */
